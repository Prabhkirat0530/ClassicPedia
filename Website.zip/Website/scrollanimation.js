window.sr = ScrollReveal();
sr.reveal('.reveal');


const reveal = {
    origin: 'left',
    delay: 200,
    distance: '120px',
    easing: 'ease-in-out',
};

window.sr = ScrollReveal({ duration: 2000 });
sr.reveal('.box', 50);